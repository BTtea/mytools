<?php
error_reporting(E_ALL & ~E_WARNING);
ini_set("memory_limit", "-1");
set_time_limit(0);
if(!file_exists("./init")){
    file_put_contents('./init','abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM');
 }
$input = './init';
// iconv -l
$iconv_list = [
    '437', '850', '852', '855', '857', '860', '861', '862', '863', '865', '866', '869', 'ANSI_X3.4-1968', 'ANSI_X3.4-1986', 'ARABIC', 'ARMSCII-8', 'ASCII', 'ASMO-708', 'BIG-5', 'BIG-FIVE', 'BIG5-HKSCS', 'BIG5', 'BIG5HKSCS', 'BIGFIVE', 'CN-BIG5', 'CN-GB', 'CN', 'CP-GR', 'CP367', 'CP437', 'CP737', 'CP775', 'CP819', 'CP850', 'CP852', 'CP855', 'CP857', 'CP858', 'CP860', 'CP861', 'CP862', 'CP863', 'CP864', 'CP865', 'CP866', 'CP869', 'CP874', 'CP932', 'CP936', 'CP949', 'CP950', 'CP1125', 'CP1133', 'CP1250', 'CP1251', 'CP1252', 'CP1253', 'CP1254', 'CP1255', 'CP1256', 'CP1257', 'CP1258', 'CP1361', 'CSASCII', 'CSEUCKR', 'CSEUCPKDFMTJAPANESE', 'CSGB2312', 'CSHPROMAN8', 'CSIBM855', 'CSIBM857', 'CSIBM860', 'CSIBM863', 'CSIBM864', 'CSIBM865', 'CSIBM866', 'CSIBM869', 'CSISO14JISC6220RO', 'CSISO2022CN', 'CSISO2022JP', 'CSISO2022JP2', 'CSISO2022KR', 'CSISOLATIN1', 'CSISOLATIN2', 'CSISOLATIN3', 'CSISOLATIN4', 'CSISOLATIN5', 'CSISOLATIN6', 'CSISOLATINARABIC', 'CSISOLATINCYRILLIC', 'CSISOLATINGREEK', 'CSISOLATINHEBREW', 'CSKOI8R', 'CSMACINTOSH', 'CSPC8CODEPAGE437', 'CSPC775BALTIC', 'CSPC850MULTILINGUAL', 'CSPC862LATINHEBREW', 'CSPCP852', 'CSSHIFTJIS', 'CSUCS4', 'CSUNICODE', 'CYRILLIC', 'ECMA-114', 'ECMA-118', 'ELOT_928', 'EUC-CN', 'EUC-JP', 'EUC-KR', 'EUC-TW', 'EUCCN', 'EUCJP', 'EUCKR', 'EUCTW', 'GB2312', 'GB18030', 'GBK', 'GB_1988-80', 'GEORGIAN-ACADEMY', 'GEORGIAN-PS', 'GREEK', 'GREEK8', 'HEBREW', 'HP-ROMAN8', 'IBM367', 'IBM437', 'IBM775', 'IBM819', 'IBM850', 'IBM852', 'IBM855', 'IBM857', 'IBM860', 'IBM861', 'IBM862', 'IBM863', 'IBM864', 'IBM865', 'IBM866', 'IBM869', 'ISO-2022-CN-EXT', 'ISO-2022-CN', 'ISO-2022-JP-2', 'ISO-2022-JP', 'ISO-2022-KR', 'ISO-8859-1', 'ISO-8859-2', 'ISO-8859-3', 'ISO-8859-4', 'ISO-8859-5', 'ISO-8859-6', 'ISO-8859-7', 'ISO-8859-8', 'ISO-8859-9', 'ISO-8859-10', 'ISO-8859-11', 'ISO-8859-13', 'ISO-8859-14', 'ISO-8859-15', 'ISO-8859-16', 'ISO-CELTIC', 'ISO-IR-6', 'ISO-IR-14', 'ISO-IR-57', 'ISO-IR-100', 'ISO-IR-101', 'ISO-IR-109', 'ISO-IR-110', 'ISO-IR-126', 'ISO-IR-127', 'ISO-IR-138', 'ISO-IR-144', 'ISO-IR-148', 'ISO-IR-157', 'ISO-IR-166', 'ISO-IR-179', 'ISO-IR-199', 'ISO-IR-203', 'ISO-IR-226', 'ISO646-CN', 'ISO646-JP', 'ISO646-US', 'ISO8859-1', 'ISO8859-2', 'ISO8859-3', 'ISO8859-4', 'ISO8859-5', 'ISO8859-6', 'ISO8859-7', 'ISO8859-8', 'ISO8859-9', 'ISO8859-10', 'ISO8859-11', 'ISO8859-13', 'ISO8859-14', 'ISO8859-15', 'ISO8859-16', 'ISO_646.IRV:1991', 'ISO_8859-1', 'ISO_8859-1:1987', 'ISO_8859-2', 'ISO_8859-2:1987', 'ISO_8859-3', 'ISO_8859-3:1988', 'ISO_8859-4', 'ISO_8859-4:1988', 'ISO_8859-5', 'ISO_8859-5:1988', 'ISO_8859-6', 'ISO_8859-6:1987', 'ISO_8859-7', 'ISO_8859-7:1987', 'ISO_8859-7:2003', 'ISO_8859-8', 'ISO_8859-8:1988', 'ISO_8859-9', 'ISO_8859-9:1989', 'ISO_8859-10', 'ISO_8859-10:1992', 'ISO_8859-14', 'ISO_8859-14:1998', 'ISO_8859-15', 'ISO_8859-15:1998', 'ISO_8859-16', 'ISO_8859-16:2001', 'JIS_C6220-1969-RO', 'JOHAB', 'JP', 'KOI8-R', 'KOI8-RU', 'KOI8-T', 'KOI8-U', 'L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8', 'L10', 'LATIN-9', 'LATIN1', 'LATIN2', 'LATIN3', 'LATIN4', 'LATIN5', 'LATIN6', 'LATIN7', 'LATIN8', 'LATIN10', 'MAC', 'MACCYRILLIC', 'MACINTOSH', 'MS-ANSI', 'MS-ARAB', 'MS-CYRL', 'MS-EE', 'MS-GREEK', 'MS-HEBR', 'MS-TURK', 'MS936', 'MS_KANJI', 'PT154', 'R8', 'RK1048', 'ROMAN8', 'SHIFT-JIS', 'SHIFT_JIS', 'SJIS', 'STRK1048-2002', 'TCVN-5712', 'TCVN', 'TCVN5712-1', 'TCVN5712-1:1993', 'TIS-620', 'TIS620-0', 'TIS620.2529-1', 'TIS620.2533-0', 'TIS620', 'UCS-2', 'UCS-2BE', 'UCS-2LE', 'UCS-4', 'UCS-4BE', 'UCS-4LE', 'UHC', 'UNICODEBIG', 'UNICODELITTLE', 'US-ASCII', 'US', 'UTF-7', 'UTF-8', 'UTF-16', 'UTF-16BE', 'UTF-16LE', 'UTF-32', 'UTF-32BE', 'UTF-32LE', 'VISCII', 'WCHAR_T', 'WINBALTRIM', 'WINDOWS-874', 'WINDOWS-936', 'WINDOWS-1250', 'WINDOWS-1251', 'WINDOWS-1252', 'WINDOWS-1253', 'WINDOWS-1254', 'WINDOWS-1255', 'WINDOWS-1256', 'WINDOWS-1257', 'WINDOWS-1258'
];
$filter_list = [
   'string.rot13',// seems no use
    'convert.iconv.*',
];
print_r($filter_list);
$prev_str = "";
$news = "";
$op_all = "";
$found_count = 0;
$op_all_max = 2000;
$last_op = "";
$init_value = file_get_contents($input);
$max_c_len = strlen($init_value) * 5;
if(!is_dir('./res')){
    mkdir('./res');
}
if(!file_exists("./res/C")){
   file_put_contents('./res/C','convert.iconv.UTF8.CSISO2022KR');
}
function getseeds($dir){
    $handler = opendir($dir);  
    while (($filename = readdir($handler)) !== false) 
    {
        if ($filename !== "." && $filename !== "..") 
        {  
            $files[] = $filename ;  
        } 
    }  
    closedir($handler);  
    return $files;
}
while(1){
    $tmp_str = "";
    //$rand = rand(1,999999);
    $op = '';
    /*if($last_op == $filter_list[0]){
         $rand_2 = rand(1,999999);
        $rand_3 = rand(1,999999);
        $icon1 = $iconv_list[$rand_2 % count($iconv_list)];
        $icon2 = $iconv_list[$rand_3 % count($iconv_list)];
        $op = str_replace('*',$icon1.'.'.$icon2,$filter_list[1]);
    } else {
        if($rand % 6 > 1){*/
            $rand_2 = rand(1,999999);
            $rand_3 = rand(1,999999);
            $icon1 = $iconv_list[$rand_2 % count($iconv_list)];
            $icon2 = $iconv_list[$rand_3 % count($iconv_list)];
            $op = str_replace('*',$icon1.'.'.$icon2,$filter_list[1]);
       /* }
        else{
            $op =  $filter_list[0];
        }
    }*/
    $tmp_str = file_get_contents('php://filter/'.$op_all.(($op_all == "")?'':'|').$op.'|convert.base64-decode|convert.base64-encode|convert.iconv.UTF8.UTF7/resource='.$input);
    if(!$tmp_str){
        continue;
    }
    if($tmp_str === $prev_str){
        continue;
    }
    if(strlen($op_all)>$op_all_max){
        $last_op = "";
        if(rand(1,999999)% 5 > 2){
            $op_all = "";
            continue;
        }
        $r_t = rand(1,999999);
        $files = getseeds('./res/');
        $r_t = $r_t % sizeof($files);
        $seed = file_get_contents('./res/'.$files[$r_t]);
        $op_all = $seed;
        echo "[mutating] ".$files[$r_t]."\n";
        continue;
    }
    if(strlen($tmp_str) > $max_c_len){
        $last_op = "";
        if(rand(1,999999)% 5 > 2){
            $op_all = "";
            continue;
        }
        $r_t = rand(1,999999);
        $files = getseeds('./res/');
        $r_t = $r_t % sizeof($files);
        $seed = file_get_contents('./res/'.$files[$r_t]);
        echo "[mutating] ".$files[$r_t]."\n";
        $op_all = $seed;
        continue;
    }
    $r = strstr($tmp_str,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",true);
    if($r === false){
        continue;
    }
    preg_match_all("/([a-zA-Z0-9])/",$r, $res);
    if(sizeof($res[0])===strlen($r) && sizeof($res[0])==1 ){
        //$ttt = quoted_printable_encode($tmp_str);
            echo "[!!] Magic:\n ------------------------------------------\n " . $tmp_str . "\n";
            if(file_exists("./res/".$r)){
                $size = strlen(file_get_contents("./res/".$r));
                if($size>strlen($op_all.(($op_all == "")?'':'|').$op)){
                    file_put_contents("./res/" . $r,  $op_all.(($op_all == "")?'':'|').$op);
                }
            }
            else{
                file_put_contents("./res/" . $r, $op_all.(($op_all == "")?'':'|').$op);
            }
            $last_op = "";
            if(rand(1,999999)% 5 > 2){
                $op_all = "";
                continue;
            }
            $r_t = rand(1,999999);
            $files = getseeds('./res/');
            $r_t = $r_t % sizeof($files);
            $seed = file_get_contents('./res/'.$files[$r_t]);
            echo "[mutating] ".$files[$r_t]."\n";
            $op_all = $seed;
            continue;
    }
    if($tmp_str === $init_value){
        $last_op = "";
        if(rand(1,999999)% 5 > 2){
            $op_all = "";
            continue;
        }
        $r_t = rand(1,999999);
        $files = getseeds('./res/');
        $r_t = $r_t % sizeof($files);
        $seed = file_get_contents('./res/'.$files[$r_t]);
        echo "[mutating] ".$files[$r_t]."\n";
        $op_all = $seed;
        continue;
    }
    else{
        $last_op = $op;
        $prev_str = $tmp_str;
        $op_all .= (($op_all == "")?'':'|').$op;

    }

}
?>
