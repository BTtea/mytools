---
name: Ask Question
about: Ask a question about dirsearch
labels: question
---

### What is the question?

What do you like to ask about?

### Any additional information?

OS, dirsearch version, python version, screenshots, dirsearch command, console output, ...?

#### Checker:
 - [ ] I read the documentation (README)
